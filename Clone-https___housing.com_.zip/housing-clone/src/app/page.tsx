import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import HousingEdgeSection from '@/components/HousingEdgeSection';
import FeaturedProperties from '@/components/FeaturedProperties';
import PopularProjects from '@/components/PopularProjects';
import ResearchInsights from '@/components/ResearchInsights';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col">
      <Header />
      <HeroSection />
      <HousingEdgeSection />
      <FeaturedProperties />
      <PopularProjects />
      <ResearchInsights />
      <Footer />
    </main>
  );
}
