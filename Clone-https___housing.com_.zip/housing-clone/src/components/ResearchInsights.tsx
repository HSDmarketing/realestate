'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { FiArrowRight } from 'react-icons/fi';

export default function ResearchInsights() {
  const insightItems = [
    {
      id: 1,
      title: 'Price Trends',
      description: 'Find property rates & price trends of top locations',
      icon: 'https://ext.same-assets.com/84575441/1955691705.svg',
      link: '/price-trends'
    },
    {
      id: 2,
      title: 'City Insights',
      description: 'Get to know about top cities before you invest',
      icon: 'https://ext.same-assets.com/84575441/1955691705.svg',
      link: '/city-insights'
    },
    {
      id: 3,
      title: 'Housing Research',
      description: 'Find reports on Indian residential market',
      icon: 'https://ext.same-assets.com/84575441/1955691705.svg',
      link: '/housing-research'
    }
  ];

  const newsItems = [
    {
      id: 1,
      title: 'Hyderabad is fastest growing city driven by real estate growth: Report',
      summary: 'Mumbai-MMR maintains steady growth across all metrics, reaffirming its position as Indias financial capital and Delhi-NCR ranks highest for its superior physical infrastructure and governance.',
      author: 'Anuradha Ramamirtham',
      date: 'Nov 2024',
      image: 'https://ext.same-assets.com/3776509358/713196106.jpeg'
    },
    {
      id: 2,
      title: 'Penthouse meaning, benefits, designs: All you wanted to know',
      summary: 'We look at what constitutes a penthouse in India and the factors that differentiate it from other regular apartments.',
      author: 'Anuradha Ramamirtham',
      date: 'Nov 2024',
      image: 'https://ext.same-assets.com/3776509358/1933845545.jpeg'
    },
    {
      id: 3,
      title: 'Sonakshi Sinha house: About the actors homes in Juhu and Bandra',
      summary: 'The top floor of the Juhu Bungalow \'Ramayan\' is where the actress stayed before her marriage to Zaheer Iqbal.',
      author: 'Anuradha Ramamirtham',
      date: 'Mar 2025',
      image: 'https://ext.same-assets.com/3776509358/4133732912.jpeg'
    }
  ];

  return (
    <section className="py-12 px-4">
      <div className="container mx-auto">
        {/* Research Insights */}
        <div className="mb-12">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">Research and Insights</h2>
              <p className="text-gray-600">Explore useful real estate insights</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {insightItems.map((item) => (
              <Link href={item.link} key={item.id}>
                <Card className="hover:shadow-md transition-shadow duration-200 border-0 h-full">
                  <CardContent className="p-6 flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-4">
                    <div className="flex-shrink-0">
                      <Image
                        src={item.icon}
                        alt={item.title}
                        width={80}
                        height={80}
                        className="object-contain"
                      />
                    </div>
                    <div className="text-center md:text-left">
                      <h3 className="font-semibold text-lg text-gray-800 flex items-center">
                        {item.title}
                        <FiArrowRight className="ml-2 text-purple-500" />
                      </h3>
                      <p className="text-sm text-gray-600 mt-2">{item.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* News and Articles */}
        <div>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">News and Articles</h2>
              <p className="text-gray-600">Read what's happening in Real Estate</p>
            </div>
            <Link href="/news" className="text-purple-700 flex items-center mt-2 md:mt-0">
              See all news and articles <FiArrowRight className="ml-2" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {newsItems.map((item) => (
              <Link href={`/news/${item.id}`} key={item.id}>
                <Card className="hover:shadow-md transition-shadow duration-200 border-0 h-full overflow-hidden">
                  <div className="relative h-48 w-full">
                    <Image
                      src={item.image}
                      alt={item.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg text-gray-800 line-clamp-2">{item.title}</h3>
                    <p className="text-sm text-gray-600 mt-2 line-clamp-3">{item.summary}</p>
                    <div className="flex justify-between items-center mt-4 text-xs text-gray-500">
                      <span>{item.author}</span>
                      <span>{item.date}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
