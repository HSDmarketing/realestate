'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { FiArrowRight } from 'react-icons/fi';

export default function FeaturedProperties() {
  const properties = [
    {
      id: 1,
      title: 'Western Springs',
      location: 'Financial District, Hyderabad',
      price: '2.19 Cr - 3.49 Cr',
      type: '3 BHK Apartment',
      image: 'https://ext.same-assets.com/3776509358/4197722644.jpeg',
      builder: {
        name: 'Western Constructions',
        logo: 'https://ext.same-assets.com/3776509358/4197722644.jpeg'
      }
    },
    {
      id: 2,
      title: 'Guru Ji Home Krishna Valley',
      location: 'Dwarka Mor, South West Delhi, New Delhi',
      price: '70.0 L - 1.25 Cr',
      type: '4 BHK Builder Floor',
      image: 'https://ext.same-assets.com/3776509358/1891735625.jpeg',
      builder: {
        name: 'Guru Ji Homes',
        logo: 'https://ext.same-assets.com/3776509358/1891735625.jpeg'
      }
    },
    {
      id: 3,
      title: 'Venkatesh Erandwane Central',
      location: 'Erandwane, Pune',
      price: '2.88 Cr - 5.1 Cr',
      type: '3, 4 BHK Apartments',
      image: 'https://ext.same-assets.com/3776509358/1933845545.jpeg',
      builder: {
        name: 'Shree Venkatesh Buildcon',
        logo: 'https://ext.same-assets.com/3776509358/1933845545.jpeg'
      }
    },
    {
      id: 4,
      title: 'DSR Valar',
      location: 'Kokapet, West Hyderabad, Hyderabad',
      price: '3.24 Cr - 4.09 Cr',
      type: '4 BHK Apartment',
      image: 'https://ext.same-assets.com/3776509358/2582698259.jpeg',
      builder: {
        name: 'DSR Infrastructure Pvt Ltd',
        logo: 'https://ext.same-assets.com/3776509358/2582698259.jpeg'
      }
    }
  ];

  return (
    <section className="py-12 px-4">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Housing's top picks</h2>
            <p className="text-gray-600">Explore top living options with us</p>
          </div>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent className="-ml-1">
            {properties.map((property) => (
              <CarouselItem key={property.id} className="pl-1 md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                <Card className="overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow duration-200">
                  <div className="relative aspect-video overflow-hidden">
                    <Image
                      src={property.image}
                      alt={property.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded-full overflow-hidden relative bg-white mr-2 flex-shrink-0">
                          <Image
                            src={property.builder.logo}
                            alt={property.builder.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <p className="text-white text-xs truncate">{property.builder.name}</p>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg text-gray-800 truncate">{property.title}</h3>
                    <p className="text-gray-600 text-sm">{property.location}</p>
                    <div className="mt-2">
                      <p className="text-gray-900 font-semibold">{property.price}</p>
                      <p className="text-gray-500 text-sm">{property.type}</p>
                    </div>
                  </CardContent>
                  <CardFooter className="p-4 pt-0">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700">
                      Contact
                    </Button>
                  </CardFooter>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="hidden md:block">
            <CarouselPrevious className="left-0" />
            <CarouselNext className="right-0" />
          </div>
        </Carousel>
      </div>
    </section>
  );
}
