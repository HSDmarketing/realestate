'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Button } from './ui/button';
import { FiUser } from 'react-icons/fi';

export default function Header() {
  return (
    <header className="w-full bg-white shadow-sm py-2 px-4 md:px-8">
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center">
          <Image
            src="https://ext.same-assets.com/84575441/860005117.png"
            alt="Housing.com"
            width={100}
            height={30}
            priority
          />
        </Link>

        {/* Navigation */}
        <div className="hidden md:flex items-center space-x-4">
          <Button variant="ghost" size="sm" className="text-neutral-600 hover:text-purple-700">
            <Link href="/edge/pay-rent">Pay Rent</Link>
          </Button>
          <Button variant="ghost" size="sm" className="text-neutral-600 hover:text-purple-700">
            <Link href="/apps">Download App</Link>
          </Button>
          <Button variant="ghost" size="sm" className="text-neutral-600 hover:text-purple-700">
            Saved
          </Button>
          <Button variant="outline" size="sm" className="text-purple-700 border-purple-700 hover:bg-purple-50">
            <Link href="/rent-sell-property">Post Property</Link>
          </Button>
          <Button variant="ghost" size="sm" className="rounded-full">
            <FiUser className="h-5 w-5" />
          </Button>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button variant="ghost" className="text-neutral-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
        </div>
      </div>
    </header>
  );
}
