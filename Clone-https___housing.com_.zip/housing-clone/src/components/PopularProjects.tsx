'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { FiArrowRight } from 'react-icons/fi';

export default function PopularProjects() {
  const projects = [
    {
      id: 1,
      title: 'Sona Vistaas',
      developer: 'Sona Valliappa Group',
      price: '1.4 Cr - 1.93 Cr',
      type: '1, 2, 2.5, 3, 3.5 BHK Apartments',
      location: 'Bannerghatta Road, Bengaluru',
      image: 'https://ext.same-assets.com/3776509358/4133732912.jpeg'
    },
    {
      id: 2,
      title: 'Incor Lake City',
      developer: 'Incor Infrastructure Pvt. Ltd.',
      price: '1.1 Cr - 1.36 Cr',
      type: '3 BHK Apartment',
      location: 'Patancheru, West Hyderabad, Hyderabad',
      image: 'https://ext.same-assets.com/3776509358/1933845545.jpeg'
    },
    {
      id: 3,
      title: 'Viloka Isha Homes',
      developer: 'Viloka Infra And Developers',
      price: '61.25 L - 84.28 L',
      type: '2, 3 BHK Apartments',
      location: 'Ameenpur, North Hyderabad, Hyderabad',
      image: 'https://ext.same-assets.com/3776509358/713196106.jpeg'
    },
    {
      id: 4,
      title: 'BPTP Amstoria Verti Greens',
      developer: 'BPTP Limited',
      price: '2.87 Cr',
      type: '2, 3 BHK Apartments',
      location: 'Sector 102, Dwarka Expressway, Gurgaon',
      image: 'https://ext.same-assets.com/3776509358/288389034.jpeg'
    }
  ];

  return (
    <section className="py-12 px-4 bg-gray-50">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Prominent projects to explore</h2>
            <p className="text-gray-600">Best projects to look out for</p>
          </div>
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full"
        >
          <CarouselContent className="-ml-1">
            {projects.map((project) => (
              <CarouselItem key={project.id} className="pl-1 md:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                <Link href={`/projects/${project.id}`}>
                  <Card className="overflow-hidden border-0 shadow-sm hover:shadow-md transition-shadow duration-200 h-full">
                    <div className="relative h-52 overflow-hidden">
                      <Image
                        src={project.image}
                        alt={project.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-base text-gray-800">{project.title}</h3>
                      <p className="text-gray-600 text-xs">by {project.developer}</p>
                      <div className="flex justify-between items-center mt-3">
                        <div>
                          <p className="text-gray-900 font-semibold text-sm">{project.price}</p>
                          <span className="inline-block bg-gray-100 text-xs text-gray-500 px-2 py-0.5 rounded mt-1">Price</span>
                        </div>
                      </div>
                      <div className="mt-2">
                        <p className="text-gray-600 text-xs">{project.type}</p>
                        <p className="text-gray-600 text-xs mt-1">{project.location}</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="hidden md:block">
            <CarouselPrevious className="left-0" />
            <CarouselNext className="right-0" />
          </div>
        </Carousel>
      </div>
    </section>
  );
}
