'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { FiSearch } from 'react-icons/fi';

export default function HeroSection() {
  const [propertyType, setPropertyType] = useState('buy');

  return (
    <section className="relative w-full h-[600px] md:h-[500px] overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src={
            propertyType === 'buy'
              ? "https://ext.same-assets.com/84575441/4270777040.jpeg"
              : "https://ext.same-assets.com/84575441/3529060143.jpeg"
          }
          alt="Housing background"
          fill
          style={{ objectFit: 'cover' }}
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-transparent z-10"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 container mx-auto flex flex-col h-full justify-center items-center text-white px-4">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-center">
          {propertyType === 'buy' ? 'Properties to buy in India' : 'Properties for rent in India'}
        </h1>
        <p className="text-sm md:text-base mb-8 text-center">
          8K+ listings added daily and 67K+ total verified
        </p>

        {/* Property Tabs */}
        <div className="w-full max-w-3xl mx-auto mb-4">
          <Tabs
            defaultValue="buy"
            className="w-full"
            onValueChange={(value) => setPropertyType(value)}
          >
            <TabsList className="grid grid-cols-5 bg-white/20 backdrop-blur-md text-white">
              <TabsTrigger value="buy" className="data-[state=active]:bg-white data-[state=active]:text-black">Buy</TabsTrigger>
              <TabsTrigger value="rent" className="data-[state=active]:bg-white data-[state=active]:text-black">Rent</TabsTrigger>
              <TabsTrigger value="commercial" className="data-[state=active]:bg-white data-[state=active]:text-black">Commercial</TabsTrigger>
              <TabsTrigger value="pg" className="data-[state=active]:bg-white data-[state=active]:text-black">PG/Co-Living</TabsTrigger>
              <TabsTrigger value="plots" className="data-[state=active]:bg-white data-[state=active]:text-black">Plots</TabsTrigger>
            </TabsList>

            {/* Search Box - Same for all tabs */}
            <TabsContent value="buy" className="mt-0">
              <div className="flex flex-col md:flex-row">
                <div className="flex-grow">
                  <Input
                    placeholder="Select City"
                    className="h-12 rounded-l-md rounded-r-none border-r-0 focus-visible:ring-0"
                  />
                </div>
                <Button className="h-12 rounded-l-none bg-teal-500 hover:bg-teal-600">
                  <FiSearch className="mr-2" /> Search
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="rent" className="mt-0">
              <div className="flex flex-col md:flex-row">
                <div className="flex-grow">
                  <Input
                    placeholder="Select City"
                    className="h-12 rounded-l-md rounded-r-none border-r-0 focus-visible:ring-0"
                  />
                </div>
                <Button className="h-12 rounded-l-none bg-teal-500 hover:bg-teal-600">
                  <FiSearch className="mr-2" /> Search
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="commercial" className="mt-0">
              <div className="flex flex-col md:flex-row">
                <div className="flex-grow">
                  <Input
                    placeholder="Select City"
                    className="h-12 rounded-l-md rounded-r-none border-r-0 focus-visible:ring-0"
                  />
                </div>
                <Button className="h-12 rounded-l-none bg-teal-500 hover:bg-teal-600">
                  <FiSearch className="mr-2" /> Search
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="pg" className="mt-0">
              <div className="flex flex-col md:flex-row">
                <div className="flex-grow">
                  <Input
                    placeholder="Select City"
                    className="h-12 rounded-l-md rounded-r-none border-r-0 focus-visible:ring-0"
                  />
                </div>
                <Button className="h-12 rounded-l-none bg-teal-500 hover:bg-teal-600">
                  <FiSearch className="mr-2" /> Search
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="plots" className="mt-0">
              <div className="flex flex-col md:flex-row">
                <div className="flex-grow">
                  <Input
                    placeholder="Select City"
                    className="h-12 rounded-l-md rounded-r-none border-r-0 focus-visible:ring-0"
                  />
                </div>
                <Button className="h-12 rounded-l-none bg-teal-500 hover:bg-teal-600">
                  <FiSearch className="mr-2" /> Search
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Property Owner CTA */}
        <div className="mt-4 text-center">
          <Button
            variant="link"
            className="text-white bg-black/30 backdrop-blur-md px-4 py-2 rounded-full hover:bg-black/40"
          >
            <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"></path>
            </svg>
            Are you a Property Owner? Sell / Rent for FREE
          </Button>
        </div>
      </div>
    </section>
  );
}
