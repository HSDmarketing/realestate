'use client';

import Image from 'next/image';
import Link from 'next/link';
import { FiFacebook, FiInstagram, FiLinkedin, FiTwitter, FiYoutube } from 'react-icons/fi';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer */}
      <div className="container mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1 */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Find Properties for Sale</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Mumbai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Bengaluru</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Hyderabad</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Pune</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Chennai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Delhi</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Gurgaon</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats in Noida</Link></li>
            </ul>
          </div>

          {/* Column 2 */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Find Properties for Rent</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Mumbai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Bengaluru</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Hyderabad</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Pune</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Chennai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Delhi</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Gurgaon</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Flats for rent in Noida</Link></li>
            </ul>
          </div>

          {/* Column 3 */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Find Residential Projects</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Mumbai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Bengaluru</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Hyderabad</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Pune</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Chennai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Delhi</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Gurgaon</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Projects in Noida</Link></li>
            </ul>
          </div>

          {/* Column 4 */}
          <div>
            <h3 className="text-lg font-semibold mb-4">City Data</h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Mumbai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Bengaluru</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Hyderabad</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Pune</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Chennai</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Delhi</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Gurgaon</Link></li>
              <li><Link href="#" className="text-gray-400 hover:text-white text-sm">Research Noida</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <Link href="/">
                <Image
                  src="https://ext.same-assets.com/84575441/3730022536.png"
                  alt="Housing.com part of REA Group"
                  width={200}
                  height={60}
                />
              </Link>
            </div>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-white">
                <FiFacebook size={20} />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <FiInstagram size={20} />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <FiLinkedin size={20} />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <FiTwitter size={20} />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white">
                <FiYoutube size={20} />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="bg-black py-4 px-4 text-center text-gray-400 text-sm">
        <p>© 2024-25 Locon Solutions Pvt. Ltd. All rights reserved.</p>
      </div>
    </footer>
  );
}
