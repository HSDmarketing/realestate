'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FiArrowRight } from 'react-icons/fi';

export default function HousingEdgeSection() {
  const services = [
    {
      id: 1,
      title: 'Pay on Credit',
      description: 'Pay your rent using Credit Card',
      image: 'https://ext.same-assets.com/84575441/3524710774.svg',
      link: '/edge/pay-rent'
    },
    {
      id: 2,
      title: 'Housing Premium',
      description: 'Instant access to zero brokerage properties',
      image: 'https://ext.same-assets.com/84575441/643841248.svg',
      link: '/premium'
    },
    {
      id: 3,
      title: 'Home Loans',
      description: 'Lowest Interest rate offers',
      image: 'https://ext.same-assets.com/84575441/2939818003.svg',
      link: '/home-loans'
    },
    {
      id: 4,
      title: 'Housing Protect',
      description: 'Protection against cyber frauds',
      image: 'https://ext.same-assets.com/84575441/2659591549.svg',
      link: '/edge/protection-plans'
    }
  ];

  return (
    <section className="py-12 px-4 bg-gray-50">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Housing Edge</h2>
            <p className="text-gray-600">Explore property related services</p>
          </div>
          <Button variant="link" className="text-purple-700 hidden md:flex items-center mt-2 md:mt-0">
            Explore Services <FiArrowRight className="ml-2" />
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {services.map((service) => (
            <Link href={service.link} key={service.id}>
              <Card className="hover:shadow-md transition-shadow duration-200 border-0 overflow-hidden">
                <CardContent className="p-6 flex flex-col items-center sm:items-start sm:flex-row md:flex-col md:items-center">
                  <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-4 md:mb-4 md:mr-0">
                    <Image
                      src={service.image}
                      alt={service.title}
                      width={60}
                      height={60}
                      className="object-contain"
                    />
                  </div>
                  <div className="text-center sm:text-left md:text-center">
                    <h3 className="font-semibold text-lg text-gray-800">{service.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <Button variant="link" className="text-purple-700 flex items-center mt-4 md:hidden mx-auto">
          Explore Services <FiArrowRight className="ml-2" />
        </Button>
      </div>
    </section>
  );
}
